from flask import render_template
from flask_login import current_user
from flask import jsonify
from flask import redirect, url_for
import datetime

from wtforms import StringField, SubmitField
from flask_wtf import FlaskForm

from app.models.user import User

from .models.own import Own
from .models.monPoke import MonPoke

from flask import Blueprint
bp = Blueprint('profile', __name__)


@bp.route('/profile')
def view_profile():

    if not current_user.is_authenticated:
        return redirect(url_for('users.login'))
    

    #get ids of owned monpokes
    monpoke_ids = Own.get_by_user_id(current_user.id)

    #actually get monpokes
    monPokes = []
    if monpoke_ids is not None:
        monPokes = [MonPoke.get_by_id(id) for id in monpoke_ids]

    print(current_user.username)

    return render_template('profile.html',
        monPoke_chars=monPokes,
        user = current_user
    )


class SearchForm(FlaskForm):
    username = StringField('Username')
    submit = SubmitField('Submit')



@bp.route('/players', methods=['GET', 'POST'])
def players():
    form = SearchForm()

    users = []
    
    if form.validate_on_submit() and len(form.username.data) >= 1:
        users = User.get_by_username(username=form.username.data)
    else:
        users = User.get_all()
        
    return render_template('players.html',
        users=users,
        form=form,
    )


@bp.route('/profile/<username>', methods=['GET'])
def username_profile(username):

    user = User.get_by_username(username = username)[0]

    #get ids of owned monpokes
    monpoke_ids = Own.get_by_user_id(user.id)

    #actually get monpokes
    monPokes = []
    if monpoke_ids is not None:
        monPokes = [MonPoke.get_by_id(id) for id in monpoke_ids]

    print(user.username)

    return render_template('profile.html',
        monPoke_chars=monPokes,
        user = user
    )