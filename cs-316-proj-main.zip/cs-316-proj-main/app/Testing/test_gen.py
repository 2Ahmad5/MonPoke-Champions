#CODE that randomly generates users and monpoke. Makes passwords and checks paswords. Modelled off the code provided

from faker import Faker
from werkzeug.security import generate_password_hash, check_password_hash

def p():
    print(__name__)

num_users = 2

fake = Faker()

print("USERS")
print("---------------------------------------------")

for uid in range(num_users):
    profile = fake.profile()
    profile = {'uid': uid, 'name': profile['name'], 'username': profile['username'], 'email': profile['mail'], 'password': generate_password_hash("a")}
    for key,value in profile.items():
        print(f"{key}: {value}")

    #print(check_password_hash(profile['password'], 'b'))
    print("\n")


num_poke = 4
types = [
    "Politician",
    "Holy",
    "Magic",
    "Scholar",
    "Athlete",
    "Tech",
    "Normal",
    "Musician",
    "Freaky",
    "Historical"
]

print("\n\n\n")
print("MONPOKE")
print("---------------------------------------------")
for pid in range(num_poke):
    poke = {}
    poke['name'] = fake.word()
    if len(poke['name']) <= 4 or len(poke['name']) >= 10:
        continue

    poke['hp'] = fake.random_int(max = 500, min = 100)
    poke['type'] = fake.random_element(elements = types)

    for key,value in poke.items():
        print(f"{key}: {value}")



    #print(check_password_hash(profile['password'], 'b'))
    print("\n")
