import random

def game():
    arr = range(1, 101, 1)
    random_element = random.choice(arr)

    print("REAL", random_element)

    reward = 5

    while(True):
        mid = (len(arr) - 1)//2
        guess = arr[mid]
        print("GUESS: ", guess)

        if guess == random_element:
            return reward
        
        reward = reward - 1

        if guess > random_element:
            arr = arr[:mid]

        else:
            arr = arr[mid + 1:]

        #print(arr)


sum = 0
for i in range(50000):
    sum += game()
    break

print(sum/50000)
