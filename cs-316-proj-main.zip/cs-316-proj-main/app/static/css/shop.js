document.addEventListener("DOMContentLoaded", function() {
    const sidebar = document.getElementById('sidebar');
    const toggleButton = document.getElementById('toggleSidebar');
    const closeButton = document.getElementById('closeSidebar');

    toggleButton.addEventListener('click', function() {
        sidebar.classList.toggle('open');
    });

    closeButton.addEventListener('click', function() {
        sidebar.classList.remove('open');
    });
});