#THIS HAS ALL THE ENDPOINTS UNITY SHOULD NEED


from flask_wtf import FlaskForm
from wtforms import Form, StringField, SubmitField
from flask import jsonify, render_template, request
from wtforms.validators import ValidationError, DataRequired, Email, EqualTo

from app.models.own import Own
from app.models.user import User

from collections import OrderedDict


from .models.monPoke import MonPoke
from .models.user import User


from flask import Blueprint
bp = Blueprint('unity', __name__)

@bp.route('/unity/login', methods=['POST'])
def unitylogin():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    user = User.get_by_auth(username, password)

    print(data, username, password, user)

    if user is None:
        return {"messege": "Invalid Username or password"}
    
    
    return jsonify(user.to_dict())


@bp.route('/unity/getById/<id>', methods=['GET'])
def monpokeByUserId(id):

    #get ids of owned monpokes
    monpoke_ids = Own.get_by_user_id(id)

    #actually get monpokes
    monPokes = []
    if monpoke_ids is not None:
        monPokes = [MonPoke.get_by_id(id) for id in monpoke_ids]

    return jsonify([m.to_dict() for m in monPokes])



@bp.route('/unity/getAll', methods=['POST'])
def unityGetAll():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    user = User.get_by_auth(username, password)

    print(data, username, password, user)

    if user is None:
        return {"messege": "Invalid Username or password"}
    

    uid = str(user.id)

    print(uid)

    #get Monpokes
    monpoke_ids = Own.get_by_user_id(uid)
    monPokes = []
    if monpoke_ids is not None:
        monPokes = [MonPoke.get_by_id(id) for id in monpoke_ids]

    
    # Ensure the order of keys
    response_data = OrderedDict([
        ("User", user.to_dict()),
        ("Monpokes", [m.to_dict() for m in monPokes])
    ])

    print(response_data)
    
    return jsonify(response_data)

@bp.route('/unity/win', methods = ['POST'])
def updateWin():
    data = request.get_json()
    winnerID = data.get('winnerID')
    loserID = data.get('loserID')

    User.add_win(winnerID)
    User.add_lose(loserID)


    return {"messege": "Successfully updated"}
