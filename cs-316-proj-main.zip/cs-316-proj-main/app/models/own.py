from flask import current_app as app
from flask import flash



class Own:
    def __init__(self, user_id, monpoke_id):
        self.user_id = user_id
        self.monpoke_id = monpoke_id



    @staticmethod
    def get_by_user_id(user_id):
        rows = app.db.execute("""
SELECT user_id, monpoke_id
FROM Owns
WHERE user_id = :user_id
""",
                              user_id=user_id)
        
        print(rows)
        print(type(rows))

        if not rows:  # email not found
            return None

        else:
            return [row[1] for row in rows]
    
    @staticmethod
    def add_card(uid, pid):
        try:
            rows = app.db.execute("""
    INSERT INTO owns (user_id, monpoke_id)
    VALUES (:uid, :pid)
    """,uid=uid, pid=pid)
        except:
            flash("Duplicate  Card Drawn")
            return None









