from flask import current_app as app
from .product import Product
from .user import User

class ShoppingCart:
    def __init__(self, uid, pid, name, price, quantity):
        self.uid = uid
        self.pid = pid
        self.name = name
        self.price = price
        self.quantity = quantity
    
    @staticmethod
    def get_cart(uid):
        rows = app.db.execute('''
        SELECT *
        FROM ShoppingCarts
        WHERE ShoppingCarts.uid = :uid
        ''',
                                uid=uid)
        return [row for row in rows] if rows else None

    @staticmethod
    def delete_cart(uid):
        rows = app.db.execute('''
    DELETE
    FROM ShoppingCarts
    WHERE ShoppingCarts.uid = :uid
    ''', uid=uid)

    @staticmethod
    def add_to_cart(uid, pid):
        rows = app.db.execute('''
        SELECT *
        FROM ShoppingCarts
        WHERE ShoppingCarts.uid = :uid
        AND ShoppingCarts.pid = :pid
        ''',uid=uid, pid=pid)
        if rows:
            rows = app.db.execute('''
            UPDATE ShoppingCarts
            SET quantity = quantity + 1
            WHERE ShoppingCarts.uid = :uid
            AND ShoppingCarts.pid = :pid
            ''',uid=uid, pid=pid)
        else:
            product = Product.get(pid)
            rows = app.db.execute("""
            INSERT INTO ShoppingCarts(uid, pid, name, price, quantity)
            VALUES(:uid, :pid, :name, :price, :quantity)
            """,
                                 uid=uid,
                                 pid=pid,
                                 name=product.name,
                                 price=product.price,
                                 quantity=1)

    @staticmethod
    def get_cost_of_cart(uid):
        cost = app.db.execute('''
        SELECT sum(price*quantity)
        FROM ShoppingCarts
        WHERE ShoppingCarts.uid = :uid
        ''',uid=uid)
        return cost
        
            

            

