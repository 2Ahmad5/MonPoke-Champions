from flask_login import UserMixin
from flask import current_app as app
from werkzeug.security import generate_password_hash, check_password_hash

from .. import login


class User(UserMixin):
    def __init__(self, id, email, username, firstname, lastname, balance, wins, games, cards):
        self.id = id
        self.email = email
        self.username = username
        self.firstname = firstname
        self.lastname = lastname
        self.balance = balance
        self.wins = wins
        self.games = games
        self.cards = cards
        

    def to_dict(self):
        return {
            "id": self.id,
            "email": self.email,
            "username": self.username,
            "firstname": self.firstname,
            "lastname": self.lastname,
            "balance": self.balance
        }





    @staticmethod
    def get_by_auth(username, password):
        rows = app.db.execute("""
SELECT password, id, email, username, firstname, lastname, balance, wins, games, cards
FROM Users
WHERE username = :username
""",
                              username=username)
        if not rows:  # username not found
            return None
        elif not check_password_hash(rows[0][0], password):
            # incorrect password
            return None
        else:
            return User(*(rows[0][1:]))
        

    @staticmethod
    def get_all():
        rows = app.db.execute("""
SELECT id, email, username, firstname, lastname, balance, wins, games, cards
FROM Users
ORDER BY wins DESC
""")
        print(rows)
        return [User(*row) for row in rows]
    

    
    @staticmethod
    def get_by_username(username):
        rows = app.db.execute('''
SELECT id, email, username, firstname, lastname, balance, wins, games, cards
FROM Users
WHERE username LIKE :username
ORDER BY wins ASC
''', username =f'{username}%')
        
        print(rows)
        
        return [User(*row) for row in rows] if rows else []
                              





    @staticmethod
    def email_exists(email):
        rows = app.db.execute("""
SELECT email
FROM Users
WHERE email = :email
""",
                              email=email)
        print("AAAAAA EMAIL")
        print(len(rows) > 0)
        return len(rows) > 0


    @staticmethod
    def username_exists(username):
        rows = app.db.execute("""
SELECT username
FROM Users
WHERE username = :username
""",
                              username=username)
        print("AAAAAA USERNAME")
        print(len(rows) > 0)
        return len(rows) > 0




    @staticmethod
    def register(email, password, username, firstname, lastname):
        try:
            rows = app.db.execute("""
INSERT INTO Users(email, password, username, firstname, lastname, balance, wins, games, cards)
VALUES(:email, :password, :username, :firstname, :lastname, 0, 0, 0, 0)
RETURNING id
""",
                                  email=email,
                                  password=generate_password_hash(password),
                                  username = username,
                                  firstname=firstname,
                                  lastname=lastname)
            id = rows[0][0]
            return User.get(id)
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None





    @staticmethod
    @login.user_loader
    def get(id):
        rows = app.db.execute("""
SELECT id, email, username, firstname, lastname, balance, wins, games, cards
FROM Users
WHERE id = :id
""",
                              id=id)
        return User(*(rows[0])) if rows else None



    @staticmethod
    def update_balance(id, cost):
        rows = app.db.execute('''
            UPDATE Users
            SET balance = balance - :cost
            WHERE Users.id = :id
            ''',id=id,cost=cost)

    @staticmethod
    def add_balance(id, currency):
        rows = app.db.execute('''
            UPDATE Users
            SET balance = balance + :currency
            WHERE Users.id = :id
            ''',id=id,currency=currency)
        
    @staticmethod
    def add_win(id):
        rows = app.db.execute('''
            UPDATE Users
            SET wins = wins + 1,
                games = games + 1
            WHERE id = :id;
            ''',id=id)
        
    @staticmethod
    def add_lose(id):
        rows = app.db.execute('''
            UPDATE Users
            SET games = games + 1
            WHERE id = :id;
            ''',id=id)
        

    @staticmethod
    def add_card(id):
        rows = app.db.execute('''
            UPDATE Users
            SET cards = cards + 1
            WHERE id = :id;
            ''',id=id)
        
