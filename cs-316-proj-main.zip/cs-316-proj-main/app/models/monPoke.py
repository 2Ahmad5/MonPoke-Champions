from flask import current_app as app

weakAgainst = {"Politician": ["Politician", "Scientist"], "Holy": ["Historical"], "Magic": ["Holy", "Magic"], "Athlete": ["Politician"], "Scientist": ["Athlete"], "Normal": ["Magic", "Freaky"], "Celebrity": ["Freaky"], "Freaky": ["Holy"], "Historical": []}
strongAgainst = {"Politician": ["Athlete"], "Magic": ["Normal", "Celebrity"],"Holy": ["Holy", "Magic", "Freaky"], "Athlete": ["Scientist"], "Scientist": ["Politician", "Scientist", "Normal"], "Normal": [], "Celebrity": ["Normal"],  "Freaky": ["Normal", "Celebrity", "Freaky"], "Historical": ["Holy", "Celebrity"]}

class MonPoke:

    def __init__(self, id, name, type1, type2, mana, health, rarity, damage):
        self.id = id
        self.name = name
        self.type1 = type1
        self.type2 = type2
        self.mana = mana
        self.health = health
        self.rarity = rarity
        self.damage = damage

    def to_dict(self):
        return {
            "id" : self.id,
            "name" : self.name,
            "type1" : self.type1,
            "type2" : self.type2,
            "rarity" : self.rarity,
            "damage" : self.damage
        }


    @staticmethod
    def get_weak(mon_type1, mon_type2):

        if not mon_type2:
            return weakAgainst[mon_type1] if mon_type1 in weakAgainst else []
        
        mon_type1_weak = weakAgainst.get(mon_type1, [])
        mon_type2_weak = weakAgainst.get(mon_type2, [])
        
        mon_type1_strong = strongAgainst.get(mon_type1, [])
        mon_type2_strong = strongAgainst.get(mon_type2, [])
        
        weaknesses = []
        
        for weakness in mon_type1_weak:
            if weakness in mon_type2_weak:
                weaknesses.append(f"{weakness} 2x")
            elif weakness not in mon_type1_strong and weakness not in mon_type2_strong:
                weaknesses.append(weakness)
        
        for weakness in mon_type2_weak:
            if weakness not in mon_type1_weak and weakness not in mon_type1_strong:
                weaknesses.append(weakness)
        
        return weaknesses

    @staticmethod
    def get_strong(mon_type1, mon_type2):

        if not mon_type2:
            return strongAgainst[mon_type1] if mon_type1 in strongAgainst else []

        mon_type1_weak = weakAgainst.get(mon_type1, [])
        mon_type2_weak = weakAgainst.get(mon_type2, [])
        
        mon_type1_strong = strongAgainst.get(mon_type1, [])
        mon_type2_strong = strongAgainst.get(mon_type2, [])
        
        strengths = []
        
        for strength in mon_type1_strong:
            if strength in mon_type2_strong:
                strengths.append(f"{strength} 2x")
            elif strength not in mon_type1_weak and strength not in mon_type2_weak:
                strengths.append(strength)
        
        for strength in mon_type2_strong:
            if strength not in mon_type1_strong and strength not in mon_type1_weak:
                strengths.append(strength)
        
        return strengths
        
    @staticmethod
    def get_extended_info(id):
        rows = app.db.execute('''
SELECT id, name, type1, type2, mana, health, rarity, damage
FROM MonPoke
WHERE id = :id
''', id =id)

        type1 = rows[0][-6]
        type2 = rows[0][-5]



        weak_against = MonPoke.get_weak(type1, type2)
        strong_against = MonPoke.get_strong(type1, type2)
        ab = app.db.execute('''
        SELECT Abilities.name, Abilities.description
        FROM Abilities, MonPoke
        WHERE MonPoke.abid = Abilities.id and MonPoke.id = :id
        
        ''', id=id)


        return MonPoke(*rows[0]) if rows else None, weak_against, strong_against, ab[0][-2], ab[0][-1]


    @staticmethod
    def get(name):
        rows = app.db.execute('''
SELECT id, name, type1, type2, mana, health, rarity, damage
FROM MonPoke
WHERE name LIKE :name
''', name =f'{name}%')
        
        return [MonPoke(*row) for row in rows] if rows else []
    


    @staticmethod
    def get_by_id(id):
        row = app.db.execute('''
SELECT id, name, type1, type2, mana, health, rarity, damage
FROM MonPoke
WHERE id = :id
''',
                                id=id)
        return MonPoke(*(row[0]))
    
    @staticmethod
    def get_by_type(type):
        rows = app.db.execute('''
SELECT id, name, type1, type2, rarity, damage
FROM MonPoke
WHERE type1 = :type or type2 = :type
''',
                                type = type)
        return[MonPoke(*row) for row in rows]
    

    @staticmethod
    def get_all():
        rows = app.db.execute('''
SELECT id, name, type1, type2, mana, health, rarity, damage
FROM MonPoke
        ''')

        return [MonPoke(*row) for row in rows]
