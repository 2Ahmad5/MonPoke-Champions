from flask import current_app as app

class MonPoke:

    def __init__(self, id, name, type1, type2):
        self.id = id
        self.name = name
        self.type1 = type1
        self.type2 = type2
        self.weakAgainst = {"Politician": ["Politician", "Scientist"], "Holy": ["Historical"], "Magic": ["Holy", "Magic"], "Athlete": ["Politician"], "Scientist": ["Athlete"], "Normal": ["Magic", "Freaky"], "Celebrity": ["Freaky"], "Freaky": ["Holy"], "Freaky": ["Holy"], "Historical": []}

    @staticmethod
    def get(name):
        rows = app.db.execute('''
SELECT id, name, type1, type2
FROM MonPoke
WHERE name LIKE :name
''', name =f'{name}%')
        
        return [MonPoke(*row) for row in rows] if rows else []
    


    @staticmethod
    def get_by_id(id):
        row = app.db.execute('''
SELECT id, name, type1, type2
FROM MonPoke
WHERE id = :id
''',
                                id=id)
        return MonPoke(*(row[0]))
    

    @staticmethod
    def get_all():
        rows = app.db.execute('''
SELECT id, name, type1, type2
FROM MonPoke
        ''')

        return [MonPoke(*row) for row in rows]

    @staticmethod
    def get_by_type(type):
        rows = app.db.execute('''
SELECT id, name, type1, type2
FROM MonPoke
WHERE type1= :type OR type2= :type
        ''',type=type)

        return [MonPoke(*row) for row in rows]
