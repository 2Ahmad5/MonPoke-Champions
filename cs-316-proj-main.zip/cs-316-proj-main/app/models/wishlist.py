from flask import current_app as app




class WishList:
   def __init__(self, id, uid, pid, name, time_purchased):
       self.id = id
       self.uid = uid
       self.pid = pid
       self.name = name
       self.time_added = time_purchased


   @staticmethod
   def get_wishlist(uid):
       rows = app.db.execute('''
SELECT *
FROM WishLists, products
WHERE WishLists.uid = :uid AND products.id = wishlists.pid
''',
                             uid=uid)
       return [row for row in rows] if rows else None


   @staticmethod
   def get_all_by_uid_since(uid, since):
       rows = app.db.execute('''
SELECT id, uid, pid, time_added
FROM WishLists
WHERE uid = :uid
AND time_added >= :since
ORDER BY time_added DESC
''',
                             uid=uid,
                             since=since)
       return [WishList(*row) for row in rows]


   @staticmethod
   def add_to_wishlist(uid, pid, name, time_added):
       try:
           id = app.db.execute("""SELECT MAX(id)+1 FROM WishLists""")[0][0]
           rows = app.db.execute("""
INSERT INTO WishLists(id, uid, pid, name, time_added)
VALUES(:id, :uid, :pid, :name, :time_added)
RETURNING id
""",
                                 id=id,
                                 uid=uid,
                                 name=name,
                                 pid=pid,
                                 time_added=time_added)
           id = rows[0][0]
           return WishList.get(id)
       except Exception as e:
           # likely email already in use; better error checking and reporting needed;
           # the following simply prints the error to the console:
           print(str(e))
           return None