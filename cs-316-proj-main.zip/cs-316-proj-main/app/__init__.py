from flask import Flask
from flask_login import LoginManager
from .config import Config
from .db import DB


login = LoginManager()
login.login_view = 'users.login'


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    app.db = DB(app)
    login.init_app(app)

    from .index import bp as index_bp
    app.register_blueprint(index_bp)

    from .users import bp as user_bp
    app.register_blueprint(user_bp)

    from .shop import bp as shop_bp
    app.register_blueprint(shop_bp)

    from .search import bp as search_bp
    app.register_blueprint(search_bp)


    from .profile import bp as profile_bp
    app.register_blueprint(profile_bp)

    from .unity import bp as unity_bp
    app.register_blueprint(unity_bp)

    return app
