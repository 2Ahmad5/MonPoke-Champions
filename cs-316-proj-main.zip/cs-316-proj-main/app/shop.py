from flask import render_template
from flask_login import current_user
from flask import jsonify
from flask import redirect, url_for, request, flash
import datetime
import random

from .models.user import User
from .models.own import Own
from .models.monPoke import MonPoke
from .models.product import Product
from .models.purchase import Purchase
from .models.wishlist import WishList
from .models.shoppingcart import ShoppingCart

from flask import Blueprint
bp = Blueprint('shop', __name__)


@bp.route('/shop')
def index():
    
    # get all available products for sale:
    products = Product.get_all(True)
    # find the products current user has bought:
    if current_user.is_authenticated:
        purchases = Purchase.get_all_by_uid_since(
            current_user.id, datetime.datetime(1980, 9, 14, 0, 0, 0))
        #get items in wishlist
        wishitems = WishList.get_wishlist(current_user.id)
        cart = ShoppingCart.get_cart(current_user.id)
    else:
        items = None
        purchases = None
    # render the page by adding information to the index.html file
    #return jsonify([item.__dict__ for item in items])
    return render_template('shop.html',
                           items_in_wishlist = wishitems,
                           items_in_cart = cart,
                           avail_products=products,
                           purchase_history=purchases)

@bp.route('/shop/add/<int:product_id>', methods=['GET','POST'])
def wishlist_add(product_id):
    if current_user.is_authenticated:
        product_info = Product.get(product_id)
        WishList.add_to_wishlist(current_user.id, product_info.id, product_info.name, datetime.datetime.now())
    return redirect(url_for('shop.index'))

@bp.route('/shop/cart', methods=["GET"])
def shopping_cart_add():
    if not current_user.is_authenticated:
        return redirect(url_for('shop.index'))
    #uid = request.args.get('uid', None) 
    pid = request.args.get('pid', None)
    uid = current_user.id
    ShoppingCart.add_to_cart(uid,pid)
    return redirect(url_for('shop.index'))

@bp.route('/shop/purchase', methods=["GET"])
def purchase_one():
    if not current_user.is_authenticated:
        flash("User is not logged in")
        return redirect(url_for('shop.index'))
    currBalance = User.get(current_user.id).balance
    pid = request.args.get('pid', None)
    product = Product.get(pid)
    if currBalance < product.price:
        flash("User does not have enough credits")
        return redirect(url_for('shop.index'))
    uid = current_user.id
    User.update_balance(uid,product.price)
    Purchase.add_to_purchase_history(uid, pid)
    card = random.choice(MonPoke.get_by_type(product.type))
    Own.add_card(uid, card.id)
    #return jsonify({"uid":uid, "pid":card.id})
    return redirect(url_for('shop.index'))

@bp.route('/shop/purchase/cart', methods=["GET"])
def purchase_cart():
    if not current_user.is_authenticated:
        flash("User is not logged in")
        return redirect(url_for('shop.index'))
    currBalance = User.get(current_user.id).balance
    cart = ShoppingCart.get_cart(current_user.id)
    cost = ShoppingCart.get_cost_of_cart(current_user.id)
    if currBalance < cost[0][0]:
        flash("User does not have enough credits")
        return redirect(url_for('shop.index'))
    
    for item in cart:
        for i in range(item.quantity):
            uid = current_user.id
            type = Product.get_type(item.pid)
            card = random.choice(MonPoke.get_by_type(type))
            Purchase.add_to_purchase_history(uid, item.pid)
            Own.add_card(uid, card.id)
    ShoppingCart.delete_cart(current_user.id)

    #return jsonify({"uid":uid, "pid":card.id})
    return redirect(url_for('shop.index'))

@bp.route('/shop/deletecart')
def delete_cart():
    if not current_user.is_authenticated:
        flash("User is not logged in")
        return redirect(url_for('shop.index'))
    ShoppingCart.delete_cart(current_user.id)

    #return jsonify({"uid":uid, "pid":card.id})
    return redirect(url_for('shop.index'))

@bp.route('/shop/addcredit')
def add_credit():
    if not current_user.is_authenticated:
        flash("User is not logged in")
        return redirect(url_for('shop.index'))
    addCurrency = request.args.get('currency', None)
    User.add_balance(current_user.id, addCurrency)

    #return jsonify({"uid":uid, "pid":card.id})
    return redirect(url_for('shop.index'))
