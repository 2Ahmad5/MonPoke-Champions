from flask import render_template
from flask_login import current_user
from flask import jsonify
from flask import redirect, url_for, request, flash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, Form, SelectField
from wtforms.validators import ValidationError, DataRequired, Email, EqualTo

import datetime
import random

from .models.user import User
from .models.own import Own
from .models.monPoke import MonPoke
from .models.product import Product
from .models.purchase import Purchase
from .models.wishlist import WishList
from .models.shoppingcart import ShoppingCart

from flask import Blueprint
bp = Blueprint('shop', __name__)

colormap = {"Relic":(255, 0, 0, 0.8)}


@bp.route('/shop')
def index():
    
    # get all available products for sale:
    products = Product.get_all(True)
    # find the products current user has bought:
    if current_user.is_authenticated:
        purchases = Purchase.get_all_by_uid_since(
            current_user.id, datetime.datetime(1980, 9, 14, 0, 0, 0))
        #get items in wishlist
        wishitems = WishList.get_wishlist(current_user.id)
        cart = ShoppingCart.get_cart(current_user.id)
    else:
        items = None
        purchases = None
    # render the page by adding information to the index.html file
    #return jsonify([item.__dict__ for item in items])
    return render_template('shop.html',
                           items_in_wishlist = wishitems,
                           items_in_cart = cart,
                           drawnCard = None,
                           avail_products=products,
                           purchase_history=purchases)

@bp.route('/shop/add/<int:product_id>', methods=['GET','POST'])
def wishlist_add(product_id):
    if current_user.is_authenticated:
        product_info = Product.get(product_id)
        WishList.add_to_wishlist(current_user.id, product_info.id, product_info.name, datetime.datetime.now())
    return redirect(url_for('shop.index'))

@bp.route('/shop/cart', methods=["GET"])
def shopping_cart_add():
    if not current_user.is_authenticated:
        return redirect(url_for('shop.index'))
    #uid = request.args.get('uid', None) 
    pid = request.args.get('pid', None)
    uid = current_user.id
    ShoppingCart.add_to_cart(uid,pid)
    return redirect(url_for('shop.index'))

@bp.route('/shop/purchase', methods=["GET"])
def purchase_one():
    global colormap
    if not current_user.is_authenticated:
        flash("User is not logged in")
        return redirect(url_for('shop.index'))
    currBalance = User.get(current_user.id).balance
    pid = request.args.get('pid', None)
    product = Product.get(pid)
    if currBalance < product.price:
        flash("User does not have enough credits")
        return redirect(url_for('shop.index'))
    uid = current_user.id
    User.update_balance(uid,product.price)
    Purchase.add_to_purchase_history(uid, pid)
    card = random.choice(MonPoke.get_by_type(product.type))
    Own.add_card(uid, card.id)
    #return jsonify({"uid":uid, "pid":card.id})

    if current_user.is_authenticated:
        purchases = Purchase.get_all_by_uid_since(
            current_user.id, datetime.datetime(1980, 9, 14, 0, 0, 0))
        #get items in wishlist
        wishitems = WishList.get_wishlist(current_user.id)
        cart = ShoppingCart.get_cart(current_user.id)
    else:
        items = None
        purchases = None
    image_path = f"media/{card.id}.jpg"
    if card.rarity == "Relic":
        backgroundcolor = colormap[card.rarity]
    else:
        backgroundcolor = (0,0,0,0)
    
    return render_template('shop.html',
                           drawnCard = card,
                           backcolor = backgroundcolor,
                           image_path = image_path,
                           items_in_wishlist = wishitems,
                           items_in_cart = cart,
                           purchase_history=purchases)

@bp.route('/shop/purchase/cart', methods=["GET"])
def purchase_cart():
    if not current_user.is_authenticated:
        flash("User is not logged in")
        return redirect(url_for('shop.index'))
    currBalance = User.get(current_user.id).balance
    cart = ShoppingCart.get_cart(current_user.id)
    cost = ShoppingCart.get_cost_of_cart(current_user.id)
    if currBalance < cost[0][0]:
        flash("User does not have enough credits")
        return redirect(url_for('shop.index'))
    
    for item in cart:
        for i in range(item.quantity):
            uid = current_user.id
            type = Product.get_type(item.pid)
            card = random.choice(MonPoke.get_by_type(type))
            Purchase.add_to_purchase_history(uid, item.pid)
            User.update_balance(uid,item.price)
            Own.add_card(uid, card.id)
    ShoppingCart.delete_cart(current_user.id)

    #return jsonify({"uid":uid, "pid":card.id})
    return redirect(url_for('shop.index'))

@bp.route('/shop/deletecart')
def delete_cart():
    if not current_user.is_authenticated:
        flash("User is not logged in")
        return redirect(url_for('shop.index'))
    
    
    ShoppingCart.delete_cart(current_user.id)

    #return jsonify({"uid":uid, "pid":card.id})
    return redirect(url_for('shop.index'))

class CreditCardForm(FlaskForm):
    cardName = StringField('Name on Card', validators=[DataRequired()])
    cardNumber = StringField('Card Number', validators=[DataRequired()])
    expirationDate = StringField('Expiration Date (MM/YY)', validators=[DataRequired()])
    cvv = StringField('CVV', validators = [DataRequired()])
    save_info = BooleanField("Save credit card information.")
    
    purch10 = SubmitField('Purchase 10 MonPoke Credits \n $5')
    purch21 = SubmitField('Purchase 20 + 1 MonPoke Credits \n $10')
    purch53 = SubmitField('Purchase 50 + 3 MonPoke Credits \n $25')

    def validate_cardNumber(form, field):
        card_number = field.data
        if len(card_number) != 19:
            raise ValidationError("Invalid card number length")
        if card_number[4] != "-" or card_number[9] != "-" or card_number[14] != "-":
            raise ValidationError("Invalid card number format, missing dashes")
        parts = card_number.split("-")
        if len(parts) != 4 or not all(part.isdigit() and len(part) == 4 for part in parts):
            raise ValidationError("Card number should only contain digits separated by dashes")

    def validate_cardName(form, field):
        lenname = len(field.data.split())
        if lenname < 2 or lenname > 3:
            raise ValidationError("Invalid Name")

    def validate_cvv(form, field):
        cvv = field.data
        if len(cvv) != 3 or not cvv.isdigit():
            raise ValidationError("Invalid cvv")

    def validate_expirationDate(form, field):
        date = field.data
        if len(date) != 5 or date[2] != "/" or not all(part.isdigit() and len(part) == 2 for part in date.split("/")):
            raise ValidationError("Invalid date")


@bp.route('/shop/add_credit')
def add_credits():
    if not current_user.is_authenticated:
        flash("User is not logged in")
        return redirect(url_for('shop.index'))
    addCurrency = request.args.get('currency', None)
    User.add_balance(current_user.id, addCurrency)

    #return jsonify({"uid":uid, "pid":card.id})
    return redirect(url_for('shop.index'))

@bp.route('/addcredits', methods=['GET', 'POST'])
def addcredits():
    form = CreditCardForm()
    if form.validate_on_submit():
        if form.purch10.data:
            User.add_balance(current_user.id, 10)
        if form.purch21.data:
            User.add_balance(current_user.id, 21)
        if form.purch53.data:
            User.add_balance(current_user.id, 53)

        flash("Purchase was successful!")
        return redirect(url_for('shop.addcredits'))
    return render_template('creditcard.html', title='Add Purchase Details', form=form)

