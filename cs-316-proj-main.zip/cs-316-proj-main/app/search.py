from flask_wtf import FlaskForm
from wtforms import Form, StringField, SubmitField
from flask import render_template
from wtforms.validators import ValidationError, DataRequired, Email, EqualTo


from .models.monPoke import MonPoke


from flask import Blueprint
bp = Blueprint('search', __name__)

class SearchForm(FlaskForm):
    search = StringField('Search')
    submit = SubmitField('Submit')

@bp.route('/search', methods=['GET', 'POST'])
def search():
    form = SearchForm()

    monPokes = []
    
    if form.validate_on_submit() and len(form.search.data) >= 1:
        monPokes = MonPoke.get(name=form.search.data)
    else:
        monPokes = MonPoke.get_all()
    return render_template('search.html',
        monPoke_chars=monPokes,
        form=form,
    )
