# Readme to tell everyone how to use the crap I code up

## Most created users will have a password equal to 'password'

Made a test file to look at randomly generating users and monpoke