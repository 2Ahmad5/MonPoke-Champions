# Readme to tell everyone how to use the crap I code up

## Most created users will have a password equal to 'password'

Unity API calls

There are three API calls I wrote for unity integration.

## http://localhost:8080/unity/login

Send a POST request with body:
```json
{
    "username": "ZzBobxX",
    "password": "password"
}
```

It will return a json body of the user with matching credentials if it exists
```json
{
    "balance": 488,
    "email": "ahbab.abeer@duke.edu",
    "firstname": "Ahbab",
    "id": 1,
    "lastname": "Abeer",
    "username": "ZzBobxX"
}
```

If no user matching user,
```json
{
    "messege": "Invalid Username or password"
}
```


## http://localhost:8080/unity/getById/<id>
You take the ID of the user, which you can get with the API call above. 
and pass it into a GET request.
For example:
http://localhost:8080/unity/getById/1

JSON Response:
```json
[
    {
        "id": 1,
        "name": "JD Vance",
        "type1": "Politician",
        "type2": null
    },
    {
        "id": 48,
        "name": "Gojo",
        "type1": "Magic",
        "type2": "Holy"
    },
    {
        "id": 2,
        "name": "Donald Trump",
        "type1": "Politician",
        "type2": "Celebrity"
    },
    {
        "id": 19,
        "name": "Batman",
        "type1": "Freaky",
        "type2": "Historical"
    },
    {
        "id": 47,
        "name": "Richard",
        "type1": "Holy",
        "type2": null
    }
]
```



## http://localhost:8080/unity/getAll
Gets User and associated Monpoke if user exists in DB


Send a POST request with body:
```json
{
    "username": "ZzBobxX",
    "password": "password"
}
```

Response:
```json
{
    "Monpokes": [
        {
            "id": 1,
            "name": "JD Vance",
            "type1": "Politician",
            "type2": null
        },
        {
            "id": 48,
            "name": "Gojo",
            "type1": "Magic",
            "type2": "Holy"
        },
        {
            "id": 2,
            "name": "Donald Trump",
            "type1": "Politician",
            "type2": "Celebrity"
        },
        {
            "id": 19,
            "name": "Batman",
            "type1": "Freaky",
            "type2": "Historical"
        },
        {
            "id": 47,
            "name": "Richard",
            "type1": "Holy",
            "type2": null
        }
    ],
    "User": {
        "balance": 488,
        "email": "ahbab.abeer@duke.edu",
        "firstname": "Ahbab",
        "id": 1,
        "lastname": "Abeer",
        "username": "ZzBobxX"
    }
}
```